package Lin.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.mysql.cj.jdbc.Driver;

@WebServlet("/loginDataCheck.do")
public class loginDataCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;
	private PrintWriter out;
	private HttpSession session;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	// 使用此方式須修改tomcat/conf/context.xml<-吃這個檔案的連結資訊
	private void Connecct1() throws Exception {
		InitialContext context = new InitialContext();

		DataSource ds = (DataSource) context.lookup("java:comp/env/connectSQLServerJdbc/OrderService");
		conn = ds.getConnection();
		boolean status = !conn.isClosed();
		out.write("status:" + status + "<br/>");
	}

	
	private void Connecct2() throws Exception {

		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String url = "jdbc:sqlserver://localhost:1433;databaseName=test;user=sa;password=P@ssw0rd";
		conn = DriverManager.getConnection(url);

		boolean status = !conn.isClosed();
		out.write("status:" + status + "<br/>");
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {

		try {
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=utf-8");

			// session用於儲存使用者資料
			session = request.getSession();

			out = response.getWriter();

			Connecct2();

			// 取得form表單資料
			String name = request.getParameter("username");
			String psd = request.getParameter("userpsd");
			out.write(name + "<br/>");
			out.write(psd + "<br/>");

			// 資料驗證 失敗就跳回登入頁面
			if (!jdbc_query(name, psd)) {
				out.write(session.getId());
				response.sendRedirect("Jsp/login.jsp");  

				out.close();
			} else {

				session.setAttribute("ssid", session.getId());
				out.write(session.getId());
				out.write("hello," + session.getAttribute("user") + "<br/>");
				out.write("hello," + session.getAttribute("userid") + "<br/>");
				response.sendRedirect("Jsp/maintainProperty.jsp");
				out.close();
			}
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private boolean jdbc_query(String name, String psd) throws SQLException {
		String sqlstr = "select * from users where username= ? and userpassword=?";
		PreparedStatement preState = conn.prepareStatement(sqlstr);
		preState.setString(1, name);
		preState.setString(2, psd);
		ResultSet rs = preState.executeQuery();

		if (rs.next()) {
			out.write(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + "<br/>");
			session.setAttribute("userid", rs.getString(1));
			session.setAttribute("user", rs.getString(2));
			return true;
		} else {

			return false;
		}

	}

}
