package Lin.javabean;

import java.io.Serializable;

public class Person implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer LinkedID;
	private String hobby;	
	private Integer gender;
	private Integer age;
	
	
	
	public Person() {
		super();
	}

	public Person(Integer linkedID) {
		super();
		LinkedID = linkedID;
	}

	public Integer getLinkedID() {
		return LinkedID;
	}
	
	//不可重設userID
//	public void setLinkedID(Integer linkedID) {
//		LinkedID = linkedID;
//	}
	
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	

}
