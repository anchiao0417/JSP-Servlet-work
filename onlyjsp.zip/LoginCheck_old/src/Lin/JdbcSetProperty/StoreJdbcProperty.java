package Lin.JdbcSetProperty;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.mysql.cj.Session;

import Lin.javabean.Person;

@WebServlet("/StoreJdbcProperty.do")
public class StoreJdbcProperty extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Connection conn;

	private PrintWriter out;

	private HttpSession session;

	private Person person;

	private Integer userid;

//	private HashMap<String, String> personfile;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {

		try {
			// 取得共用session
			request.setCharacterEncoding("UTF-8");
			session = request.getSession();
			response.setContentType("text/html;charset=utf-8");
			out = response.getWriter();

			// 取得userID
			userid = Integer.parseInt((String) session.getAttribute("userid"));

			// form表單數值轉型
			String hobby = (String) request.getParameter("hobby");
			Integer gender = (request.getParameter("gender").equals("m")) ? 1 : 0;
			Integer age = Integer.parseInt(request.getParameter("age"));

			//測試用輸出
			out.write("==================表單資料======================<br/>");
			out.write(hobby + "<br/>");
			out.write(request.getParameter("gender") + "<br/>");
			out.write(gender + "<br/>");
			out.write(age + "<br/>");
			out.write(userid + "<br/>");
			out.write("==================表單資料結束======================<br/>");
			
			Connecct2();

			/// 確認是否資料庫有該會員資料
			boolean isnewperson = !query(userid);

			if (isnewperson) {
				// 新進會員寫入資料
				insert(hobby, gender, age);
			} else {
				// 如果重複就更新
				update(hobby, gender, age);
			}

			// 將會員資料寫入session javabean
			person = new Person(userid);

			// 查詢並設定session.person給jsp共用
			setPerson(userid);

			response.sendRedirect("Jsp/showPersonalFile.jsp");

			out.close();
			conn.close();

		} catch (Exception e) {
			
			//輸入不合法就存錯誤訊息在session
			session.setAttribute("errorString", "invalid data type, pls check and re-submit");
			try {
				//並導向到輸入頁面
				response.sendRedirect("Jsp/maintainProperty.jsp");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}

	}

	private void setPerson(Integer userid) throws SQLException {
		String sqlstr = "select * from personalinfo where LinkedID=?";
		PreparedStatement preState = conn.prepareStatement(sqlstr);
		preState.setInt(1, userid);
		ResultSet rs = preState.executeQuery();

		// 不為null表示已經經過update/insert
		if (person != null) {
			rs.next();
			out.write("person is not null<br/>");
			person.setHobby(rs.getString(2));
			person.setAge(rs.getInt(4));
			person.setGender(rs.getInt(3));

			session.setAttribute("person", person);

		} else {
			out.write("person is null<br/>");
		}

	}

	private void update(String hobby, Integer gender, Integer age) throws SQLException {
		out.write("updatee<br/>");
		String sqlstr = "update personalinfo set hobby=?,gender=?,age=? where LinkedID=?";
		PreparedStatement preState = conn.prepareStatement(sqlstr);
		preState.setString(1, hobby);
		preState.setInt(2, gender);
		preState.setInt(3, age);
		preState.setInt(4, userid);
		preState.execute();
		out.write("update done<br/>");
	}

	private void insert(String hobby, Integer gender, Integer age) throws SQLException {
		out.write("inserte<br/>");
		//前置N強迫SQL以UNICODE讀取(default big5 lead to garbled text)
		String sqlstr = "insert personalinfo (LinkedID,hobby,gender,age) values(N?,?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sqlstr);
		preState.setInt(1, userid);
		preState.setString(2, hobby);
		preState.setInt(3, gender);
		preState.setInt(4, age);
		preState.execute();
		out.write("insert done<br/>");
	}

	private boolean query(Integer userid) throws SQLException {
		out.write("query<br/>");
		String sqlstr = "select * from personalinfo where LinkedID=?";
		PreparedStatement preState = conn.prepareStatement(sqlstr);
		preState.setInt(1, userid);
		ResultSet rs = preState.executeQuery();

		
		//除錯用輸出
		if (rs.next()) {
			out.write("==================資料庫資料======================<br/>");
			out.write("has data<br/>");
			out.write(rs.getInt(1) + "<br/>");
			out.write(rs.getString(2) + "<br/>");
			out.write(rs.getInt(3) + "<br/>");
			out.write(rs.getInt(4) + "<br/>");
			out.write("==================資料庫資料結束======================<br/>");

			return true;
		} else {
			out.write("==================資料庫資料======================<br/>");
			out.write("no data<br/>");
			out.write("==================資料庫資料結束======================<br/>");

			return false;

		}
	}

	//使用此方式須修改tomcat/conf/context.xml
	private void Connecct1() throws Exception {
		InitialContext context = new InitialContext();

		DataSource ds = (DataSource) context.lookup("java:comp/env/connectSQLServerJdbc/OrderService");
		conn = ds.getConnection();
		boolean status = !conn.isClosed();
		out.write("connect status:" + status + "<br/>");
	}

	
	private void Connecct2() throws Exception {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String url = "jdbc:sqlserver://localhost:1433;databaseName=test;user=sa;password=P@ssw0rd";

		conn = DriverManager.getConnection(url);

		boolean status = !conn.isClosed();
		out.write("status:" + status + "<br/>");
	}

}
